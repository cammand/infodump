# CHANGELOG

## v1.0.2 (2014-09-17)
- fixed bug when you create a message via View (incorrect namespace)

## v1.0.1 (2014-09-15)
- fixed bug in the attachment file.
- In `\Phalcon\Mailer\Message`, creation SwiftMailer of instances moved to the DI

## v1.0.0 (2014-09-14)
- Release of component :) 