<?php
return array(
    'root'  =>  array(
        'route' =>  '/',
        'paths' =>  array(
            'module' => 'Home',
            'controller' => 'Frontend\Home',
            'action' => 'index'
        )
    )
);