<?php
return [
    'root' => [
        'route' => '/',
        'paths' => [
            'module' => 'Example',
            'controller' => 'Frontend\Home',
            'action' => 'index'
        ]
    ]
];