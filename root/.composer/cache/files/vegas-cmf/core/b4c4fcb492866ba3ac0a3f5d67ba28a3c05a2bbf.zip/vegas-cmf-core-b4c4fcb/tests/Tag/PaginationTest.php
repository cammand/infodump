<?php
/**
 * This file is part of Vegas package
 *
 * @author Arkadiusz Ostrycharz <aostrycharz@amsterdam-standard.pl>
 * @copyright Amsterdam Standard Sp. Z o.o.
 * @homepage http://vegas-cmf.github.io
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
namespace Vegas\Tests\Tag;

use Vegas\Paginator\Adapter\Mongo;
use Vegas\Tag\Pagination;
use Vegas\Test\TestCase;
use Vegas\Tests\Stub\Models\FakeModel;
use Vegas\Tests\Stub\Models\FakePaginatorModel;

class RequestMock
{
    public function get()
    {
        return [
            'by' => 'name',
            'order' => 'asc'
        ];
    }
}

class PaginationTest extends TestCase
{
    public function testException()
    {
        try {
            $paginator = new Mongo(array());
            throw new \Exception('Not this exception.');
        } catch (\Exception $ex) {
            $this->assertInstanceOf('\Vegas\Paginator\Adapter\Exception\ModelNotSetException', $ex);
        }

        /*try {
            $paginator = new Mongo(array(
                'modelName' => '\Vegas\Tests\Stub\Models\FakeModel',
            ));
            throw new \Exception('Not this exception.');
        } catch (\Exception $ex) {
            $this->assertInstanceOf('\Vegas\Paginator\Adapter\Exception\DbNotSetException', $ex);
        }*/
    }

    public function testRender()
    {
        $this->createObjectCollection();

        $pagination = new Pagination($this->di);

        $paginator = new Mongo(array(
            'db' => $this->di->get('mongo'),
            'modelName' => '\Vegas\Tests\Stub\Models\FakeModel',
            'query' => array('test_name' => 'PaginationTest'),
            'limit' => 10,
            'page' => 1,
            'sort' => [
                'created_at' => -1
            ]
        ));

        $this->assertEquals(
            '<ul class="pagination"><li class="prev not-active"><a href="/?page=1">Previous</a></li><li class="active"><a href="/?page=1">1</a></li><li class=""><a href="/?page=2">2</a></li><li class="next"><a href="/?page=2">Next</a></li></ul>',
            $pagination->render($paginator->getPaginate())
        );

        $paginator = new Mongo(array(
            'db' => $this->di->get('mongo'),
            'modelName' => '\Vegas\Tests\Stub\Models\FakeModel',
            'query' => array('test_name' => 'PaginationTest'),
            'page' => 2
        ));

        $this->assertEquals(
            '<ul class="pagination"><li class="prev"><a href="/?page=1">Previous</a></li><li class=""><a href="/?page=1">1</a></li><li class="active"><a href="/?page=2">2</a></li><li class="next not-active"><a href="/?page=2">Next</a></li></ul>',
            $pagination->render($paginator->getPaginate())
        );

        $paginate = $paginator->getPaginate();
        $paginate->current = '99';
        $paginate->total_pages = '2';

        $this->assertEquals(
            '<ul class="pagination"><li class="prev"><a href="/?page=1">Previous</a></li><li class=""><a href="/?page=1">1</a></li><li class=""><a href="/?page=2">2</a></li><li class="next not-active"><a href="/?page=2">Next</a></li></ul>',
            $pagination->render($paginate)
        );

        $paginator = new Mongo(array(
            'db' => $this->di->get('mongo'),
            'modelName' => '\Vegas\Tests\Stub\Models\FakeModel',
            'query' => array('test_name' => 'PaginationTest'),
            'page' => 2
        ));
        $paginator->setCurrentPage(2);
        $this->assertEquals(
            '<ul class="pagination"><li class="prev"><a href="/?page=1">Previous</a></li><li class=""><a href="/?page=1">1</a></li><li class="active"><a href="/?page=2">2</a></li><li class="next not-active"><a href="/?page=2">Next</a></li></ul>',
            $pagination->render($paginator->getPaginate())
        );

        $paginate = $paginator->getPaginate();
        $paginate->currentUri = 'test';
        $this->assertEquals(
            '<ul class="pagination"><li class="prev"><a href="test?page=1">Previous</a></li><li class=""><a href="test?page=1">1</a></li><li class="active"><a href="test?page=2">2</a></li><li class="next not-active"><a href="test?page=2">Next</a></li></ul>',
            $pagination->render($paginate)
        );

        $page = $paginator->getPaginate();
        $this->assertSame(1, $page->before);
        $this->assertSame(null, $page->next);
        $this->assertSame(2, $page->current);
        $this->assertSame(10, count($page->items));
        $this->assertSame(2, $page->total_pages);


    }

    public function testOffset()
    {
        $pagination = new Pagination($this->di);

        for($i = 1; $i <= 20; $i++) {
            $model = new FakePaginatorModel;
            $model->fake_field = $i;
            $model->save();
        }

        $paginator = new Mongo(array(
            'db' => $this->di->get('mongo'),
            'modelName' => '\Vegas\Tests\Stub\Models\FakePaginatorModel',
            'query' => [],
            'page' => 5,
            'limit' => 2
        ));

        $this->assertEquals(
            '<ul class="pagination"><li class="prev"><a href="/?page=4">Previous</a></li><li class=""><a href="/?page=1">1</a></li><li class=""><a href="/?page=2">2</a></li><li class=""><a href="/?page=3">3</a></li><li class=""><a href="/?page=4">4</a></li><li class="active"><a href="/?page=5">5</a></li><li class=""><a href="/?page=6">6</a></li><li class=""><a href="/?page=7">7</a></li><li class="more"><a href="/?page=5">...</a></li><li class=""><a href="/?page=9">9</a></li><li class=""><a href="/?page=10">10</a></li><li class="next"><a href="/?page=6">Next</a></li></ul>',
            $pagination->render($paginator->getPaginate(), ['middle_offset' => 2])
        );

        foreach (FakePaginatorModel::find() as $robot) {
            $robot->delete();
        }
    }

    public function testArguments()
    {
        $this->createObjectCollection();
        $this->di->setShared('request', function(){
           return new RequestMock();
        });

        $pagination = new Pagination($this->di);

        $paginator = new Mongo(array(
            'db' => $this->di->get('mongo'),
            'modelName' => '\Vegas\Tests\Stub\Models\FakeModel',
            'query' => array('test_name' => 'PaginationTest'),
            'limit' => 10,
            'page' => 1,
            'sort' => [
                'created_at' => -1
            ]
        ));

        $this->assertEquals(
            '<ul class="pagination"><li class="prev not-active"><a href="/?page=1&by=name&order=asc">Previous</a></li><li class="active"><a href="/?page=1&by=name&order=asc">1</a></li><li class=""><a href="/?page=2&by=name&order=asc">2</a></li><li class="next"><a href="/?page=2&by=name&order=asc">Next</a></li></ul>',
            $pagination->render($paginator->getPaginate(), ['sorting' => ['by' => 'name', 'order' => 'asc']])
        );

    }

    private function createObjectCollection()
    {
        for ($i = 0; $i<20; $i++) {
            $fakeModel = new FakeModel();
            $fakeModel->fake_field = uniqid();
            $fakeModel->test_name = 'PaginationTest';
            $fakeModel->save();
        }
    }

    public function tearDown()
    {
        $fakeModels = FakeModel::find(array(array(
            'test_name' => 'PaginationTest'
        )));

        foreach ($fakeModels As $fakeModel) {
            $fakeModel->delete();
        }
    }
}