Vegas CMF Core
==============

[![Build Status](https://travis-ci.org/vegas-cmf/core.png?branch=master)](https://travis-ci.org/vegas-cmf/core)
[![Coverage Status](https://coveralls.io/repos/vegas-cmf/core/badge.png?branch=master)](https://coveralls.io/r/vegas-cmf/core?branch=master)
[![Latest Stable Version](https://img.shields.io/packagist/v/vegas-cmf/core.svg)](https://packagist.org/packages/vegas-cmf/core)
[![Total Downloads](https://img.shields.io/packagist/dt/vegas-cmf/core.svg)](https://packagist.org/packages/vegas-cmf/core)

Read the docs at [http://vegas-cmf.github.io/1.0/guide.html](http://vegas-cmf.github.io/1.0/guide.html)
