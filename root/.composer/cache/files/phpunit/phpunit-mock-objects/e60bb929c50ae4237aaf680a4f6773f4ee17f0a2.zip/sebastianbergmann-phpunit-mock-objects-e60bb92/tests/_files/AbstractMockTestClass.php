<?php
abstract class AbstractMockTestClass
{
    abstract public function doSomething();

    public function returnAnything()
    {
        return 1;
    }
}
