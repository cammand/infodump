<?php
class ClassWithStaticMethod
{
    public static function staticMethod()
    {
    }
}
