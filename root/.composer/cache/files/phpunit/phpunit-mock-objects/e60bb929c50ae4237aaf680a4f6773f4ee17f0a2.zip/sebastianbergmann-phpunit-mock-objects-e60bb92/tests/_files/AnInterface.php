<?php
interface AnInterface
{
    public function doSomething();
}
